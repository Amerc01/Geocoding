package com.example.geocodingmaci;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.xml.sax.SAXException;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button ottieniCoordinate = findViewById(R.id.ottieniCoordinate);
        ottieniCoordinate.setOnClickListener(view -> {
            onClickOttieniCoordinate();
        });
    }

    private void onClickOttieniCoordinate() {
        //prendo il valore inserito dall'utente
        EditText address = findViewById(R.id.indirizzo);
        String indirizzo = address.getText().toString();

        new Thread(() -> {
            //thread che effettua la richiesta asincrona
            WSConnection request = new WSConnection();
            //getRate effettua la richiesta al server
            //fa il parsing della risposta
            //e restituisce il valore del tasso di conversione

            String coord = null;
            try {
                coord = request.getXML(indirizzo);
            } catch (ParserConfigurationException | IOException | SAXException e) {
                e.printStackTrace();
            }

            Handler handler = new Handler(Looper.getMainLooper());
            String finalCoord = coord;
            boolean post = handler.post(() -> {
                //modifica all'interfaccia
                //calcolo il valore in euro

                TextView result = MainActivity.this.findViewById(R.id.resultField);
                result.setText(finalCoord);

            });
        }).start();
    }
}
