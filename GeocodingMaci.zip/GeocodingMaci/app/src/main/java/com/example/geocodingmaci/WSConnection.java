package com.example.geocodingmaci;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class WSConnection {

    private String urlString = "https://maps.googleapis.com/maps/api/geocode/xml?address=";
    private String key = "&key=AIzaSyC5bWt_j_tMxXx-Z7Xz-k8YnQQ2b-nFdDU";
    private String address;
    private String latitude;
    private String longitude;

    public String getXML(String address) throws ParserConfigurationException, IOException, SAXException {
        URL url = new URL(urlString + address + key);
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Accept", "application/xml");

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = db.parse(conn.getInputStream());

        doc.getDocumentElement().normalize();

        NodeList nList = doc.getElementsByTagName("lat");
        Element eElement = (Element) nList.item(0);
        String lat = eElement.getTextContent();

        nList = doc.getElementsByTagName("lng");
        eElement = (Element) nList.item(0);
        String lng = eElement.getTextContent();

        return lat + "," + lng;

    }
}
